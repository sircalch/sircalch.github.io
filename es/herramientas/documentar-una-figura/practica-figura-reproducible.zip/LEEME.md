# Reproduce una figura y documenta qué cambió

Andrés Monreal Ciencia. Práctica con seis observaciones ficticias de temperatura. `figura.png` muestra el resultado en Celsius. `ficha-figura.md` sirve para documentar una figura propia.

## Repite la figura

Extrae el ZIP y abre una terminal dentro de la carpeta. El ejemplo se probó con Python 3.12.10 y Matplotlib 3.11.1. Si ya tienes Matplotlib puedes ejecutar el script directamente.

```console
python -m pip install -r requirements.txt
python reproducir_figura.py --unidad C --salida repetida-c.png
```

La salida debe tener seis puntos entre 0 y 25 s, con una primera lectura de 20.0 °C y una última de 27.0 °C. Se grafican todas las filas del CSV en orden y se conectan con líneas. El archivo de referencia se conserva al darle otro nombre a la salida.

## Cambia una decisión

```console
python reproducir_figura.py --unidad F --salida repetida-f.png
```

Comprueba que sigan apareciendo seis puntos entre 0 y 25 s. El eje vertical pasa a Fahrenheit y la primera y última lectura deben ser 68.0 y 80.6 °F. Anota en la ficha la conversión `F = C × 9/5 + 32`, el parámetro elegido, el comando y la nueva salida. Pídele a otra persona que repita el resultado a partir de lo que anotaste.

## Ficha del ejemplo en Celsius

| Campo | Registro |
|---|---|
| Pregunta | Cómo cambian las lecturas durante los 25 segundos del ejemplo |
| Entrada | `mediciones.csv`, seis observaciones ficticias, una por fila |
| Unidades de entrada | `tiempo_s` en segundos y `temperatura_c` en Celsius |
| Transformación | Celsius, sin conversiones. Se usan las seis filas |
| Código y entorno probado | `reproducir_figura.py`, Python 3.12.10, Matplotlib 3.11.1 |
| Comando de referencia | `python reproducir_figura.py --unidad C --salida figura.png` |
| Resultado | Seis puntos, ejes Tiempo (s) y Temperatura (°C), extremos de 20.0 y 27.0 °C |

Los valores y las unidades sirven para comprobar el resultado aunque se vean diferencias de tipografía entre equipos. [Guía de Andrés Monreal Ciencia](https://sircalch.github.io/es/herramientas/documentar-una-figura/)
