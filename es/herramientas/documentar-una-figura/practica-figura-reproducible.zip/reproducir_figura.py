"""Dibuja las lecturas de temperatura de la práctica en grados Celsius o Fahrenheit."""

import argparse
import csv
from math import isfinite
from pathlib import Path

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure


HERE = Path(__file__).resolve().parent


def read_measurements(path):
    times, temperatures = [], []
    with path.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        if reader.fieldnames != ["tiempo_s", "temperatura_c"]:
            raise ValueError("El CSV debe tener las columnas tiempo_s y temperatura_c")
        for row in reader:
            try:
                time = float(row["tiempo_s"])
                temperature = float(row["temperatura_c"])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"La fila {reader.line_num} debe contener dos números") from exc
            if not (isfinite(time) and isfinite(temperature)) or time < 0:
                raise ValueError(f"La fila {reader.line_num} contiene una medición inválida")
            if times and time <= times[-1]:
                raise ValueError(f"El tiempo debe crecer estrictamente. Revisa la fila {reader.line_num}")
            times.append(time)
            temperatures.append(temperature)
    if len(times) < 2:
        raise ValueError("Se necesitan dos mediciones como mínimo")
    return times, temperatures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datos", type=Path, default=HERE / "mediciones.csv")
    parser.add_argument("--unidad", choices=("C", "F"), default="C")
    parser.add_argument("--salida", type=Path, default=HERE / "figura.png")
    args = parser.parse_args()
    try:
        times, temperatures = read_measurements(args.datos)
        if args.unidad == "F":
            temperatures = [value * 9 / 5 + 32 for value in temperatures]
        figure = Figure(figsize=(7.6, 4.5), layout="constrained")
        FigureCanvasAgg(figure)
        axes = figure.subplots()
        axes.plot(times, temperatures, "o-", color="#167D83", linewidth=2.3, markersize=6)
        axes.set(title="Calentamiento de una muestra · datos ficticios",
                 xlabel="Tiempo (s)", ylabel=f"Temperatura (°{args.unidad})")
        axes.grid(axis="y", alpha=0.28)
        figure.savefig(args.salida, dpi=160, metadata={"Title": "Práctica de figura reproducible"})
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Error: {exc}\n")
    print(f"{len(times)} puntos. {times[0]:g} a {times[-1]:g} s. "
          f"Primera lectura {temperatures[0]:.1f} °{args.unidad}. "
          f"Última lectura {temperatures[-1]:.1f} °{args.unidad}.")


if __name__ == "__main__":
    main()
